package com.example.psifiakidiakivernisi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaTimestamp;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth mAuth;
    private TextView banner, registerUser;
    private EditText fullName, email, password, age, address, bloodType, emergency_contact, known_sickness, personal_phone;
    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_user);

        mAuth = FirebaseAuth.getInstance();
        banner = (TextView) findViewById(R.id.banner);
        banner.setOnClickListener(this);

        registerUser = (Button) findViewById(R.id.registerUser);
        registerUser.setOnClickListener(this);

        fullName = (EditText) findViewById(R.id.fullName);
        age = (EditText) findViewById(R.id.age);
        address = (EditText) findViewById(R.id.address);
        bloodType = (EditText) findViewById(R.id.bloodType);
        emergency_contact = (EditText) findViewById(R.id.emergency_contact);
        known_sickness = (EditText) findViewById(R.id.known_sickness);
        personal_phone = (EditText) findViewById(R.id.personal_phone);
        password = (EditText) findViewById(R.id.password);
        email= (EditText) findViewById(R.id.email);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.banner:
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.registerUser:
                registerUser();
                break;
        }
    }

    private void registerUser(){
        String fullName2 = fullName.getText().toString().trim();
        String address2 = address.getText().toString().trim();
        String bloodType2 = bloodType.getText().toString().trim();
        String age2 = age.getText().toString().trim();
        String emergency_contact2 = emergency_contact.getText().toString().trim();
        String known_sickness2 = known_sickness.getText().toString().trim();
        String personal_phone2 = personal_phone.getText().toString().trim();
        String password2 = password.getText().toString().trim();
        String email2 = email.getText().toString().trim();

        if(fullName2.isEmpty()){
            fullName.setError("Full Name is required!");
            fullName.requestFocus();
            return;
        }
        if(password2.isEmpty()){
            password.setError("Password is required!");
            password.requestFocus();
            return;
        }
        if(email2.isEmpty()){
            email.setError("Email is required!");
            email.requestFocus();
            return;
        }

        if(age2.isEmpty()){
            age.setError("Age is required!");
            age.requestFocus();
            return;
        }
        if(address2.isEmpty()){
            address.setError("Address is required!");
            address.requestFocus();
            return;
        }
        if(bloodType2.isEmpty()){
            bloodType.setError("bloodType is required!");
            bloodType.requestFocus();
            return;
        }
        if(emergency_contact2.isEmpty()){
            emergency_contact.setError("emergency_contact is required!");
            emergency_contact.requestFocus();
            return;
        }
        if(known_sickness2.isEmpty()){
            known_sickness.setError("known_sickness is required!");
            known_sickness.requestFocus();
            return;
        }
        if(personal_phone2.isEmpty()){
            personal_phone.setError("personal_phone is required!");
            personal_phone.requestFocus();
            return;
        }


        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email2,password2).addOnCompleteListener(task -> {
            if(task.isSuccessful()){
                User user = new User(fullName2,password2,email2, age2, address2, bloodType2, emergency_contact2, known_sickness2, personal_phone2);
                FirebaseDatabase.getInstance("https://psifiakidiakivernisi-default-rtdb.europe-west1.firebasedatabase.app").getReference("Users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(user).addOnCompleteListener(task1 -> {
                    if(task1.isSuccessful()){
                        Toast.makeText(Register.this, "User has been registered succesfully!", Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);

                    }else{
                        Toast.makeText(Register.this, "Failed to register! Try Again 1", Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                        System.out.println("This is task 1 :");
                        System.out.println(task1);
                    }
                });
            }else{
                Toast.makeText(Register.this, "Failed to register! Try Again 2", Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.GONE);
                System.out.println("This is task :");
                System.out.println(task.getResult());

            }
        });

    }
}