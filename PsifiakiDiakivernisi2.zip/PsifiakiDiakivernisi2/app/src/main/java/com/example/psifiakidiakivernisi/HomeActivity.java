package com.example.psifiakidiakivernisi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{

    private Button mapButton;
    private static final String TAG = "HomeActivity";
    private static final int ERROR_DIALOG_REQUEST=9001;

    private FirebaseUser user;
    private DatabaseReference reference;
    private String userID;
    private Button logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mapButton = (Button)findViewById(R.id.mapButton);
        mapButton.setOnClickListener(this);

        logout = (Button)findViewById(R.id.signOut);
        logout.setOnClickListener(this);

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userID = user.getUid();

        final TextView fullNameTextView = (TextView) findViewById(R.id.fullNameTextView);
        final TextView emailTextView = (TextView) findViewById(R.id.emailTextView);
        final TextView ageTextView = (TextView) findViewById(R.id.ageTextView);
        final TextView bloodTypeTextView = (TextView) findViewById(R.id.bloodTypeTextView);

        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userProfile = snapshot.getValue(User.class);

                if(userProfile != null){
                    String fullName = userProfile.fullName;
                    String email = userProfile.email;
                    String age = userProfile.age;
                    String blood_type = userProfile.bloodType;

                    fullNameTextView.setText(fullName);
                    emailTextView.setText(email);
                    ageTextView.setText(age);
                    bloodTypeTextView.setText(blood_type);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(HomeActivity.this, "Something wrong happened", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onClick(View view) {
            if(R.id.mapButton == view.getId()) {
                if (isServicesOkey()) {
                    startActivity(new Intent(this, MapsActivity.class));
                } else {
                    Toast.makeText(this, "Something wrong Happened with Google Services", Toast.LENGTH_SHORT).show();
                }
            }else if(R.id.signOut == view.getId()){
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(this, MainActivity.class));
            }


    }

    public boolean isServicesOkey(){
        int available = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(HomeActivity.this);
        if(available == ConnectionResult.SUCCESS){
            Log.d(TAG, "Services Okey");
            return true;
        }else if(GoogleApiAvailability.getInstance().isUserResolvableError(available)){
            Log.d(TAG, "error occurred but fixable");
            Dialog dialog = GoogleApiAvailability.getInstance().getErrorDialog(HomeActivity.this,available, ERROR_DIALOG_REQUEST);
            dialog.show();
        }else{
            Toast.makeText(this, "Cant make map req", Toast.LENGTH_LONG).show();

        }
        return false;
    }
}