package com.example.psifiakidiakivernisi;

public class User {
    public String fullName, password,email, age, address, bloodType, emergency_contact, known_sickness, personal_phone;

    public User(){

    }
    public User(String fullName, String password,String email, String age, String address, String bloodType, String emergency_contact, String known_sickness, String personal_phone){
        this.fullName = fullName;
        this.password = password;
        this.email = email;
        this.age = age;
        this.address = address;
        this.bloodType = bloodType;
        this.emergency_contact = emergency_contact;
        this.known_sickness = known_sickness;
        this.personal_phone = personal_phone;
    }
}
